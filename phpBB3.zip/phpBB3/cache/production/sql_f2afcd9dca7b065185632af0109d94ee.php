<?php exit; ?>
1575655569
SELECT * FROM phpbb_styles s WHERE s.style_id = 2
298
a:1:{i:0;a:8:{s:8:"style_id";s:1:"2";s:10:"style_name";s:10:"myInvision";s:15:"style_copyright";s:22:"© MannixMD, @MannixMD";s:12:"style_active";s:1:"1";s:10:"style_path";s:10:"MyInvision";s:15:"bbcode_bitfield";s:4:"//g=";s:15:"style_parent_id";s:1:"1";s:17:"style_parent_tree";s:9:"prosilver";}}