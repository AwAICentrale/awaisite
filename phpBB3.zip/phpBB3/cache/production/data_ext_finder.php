<?php exit; ?>
1607178531
312
a:2:{s:32:"d02806c98648acbc3e4c04be69a4e244";a:1:{i:0;a:4:{s:10:"named_path";s:50:"ext/phpbb/viglink/language/en/info_acp_viglink.php";s:8:"ext_name";s:13:"phpbb/viglink";s:4:"path";s:30:"ext/phpbb/viglink/language/en/";s:8:"filename";s:20:"info_acp_viglink.php";}}s:32:"0d47a9bd48f85126d4a6de772998c56e";a:0:{}}